class Function_variable():
    def __init__(self, inp):
        self.var = inp


kek = Function_variable("lol")
print(kek.var)
