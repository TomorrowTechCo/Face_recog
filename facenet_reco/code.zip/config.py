classifier_path = "/facial_recog/output/classifier2.pkl"
embeddings_path = "/facial_recog/output/embeddings.pkl"
